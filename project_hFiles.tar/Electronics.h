//
// Created by Joanita on 2020/10/27.
//

#ifndef PROJECT_ELECTRONICS_H
#define PROJECT_ELECTRONICS_H

#include <iostream>
#include <string>

using namespace std;

class Electronics{
    string type;
    int efficiency;
};

#endif //PROJECT_ELECTRONICS_H
