//
// Created by Joanita on 2020/10/27.
//

#ifndef PROJECT_ENGINE_H
#define PROJECT_ENGINE_H

#include <string>
#include <iostream>

using namespace std;

class Engine {
private:
    string type;
    int horsePower;
    int torque;
};
#endif //PROJECT_ENGINE_H
