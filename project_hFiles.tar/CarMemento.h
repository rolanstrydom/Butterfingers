//
// Created by Joanita on 2020/10/27.
//

#ifndef PROJECT_CARMEMENTO_H
#define PROJECT_CARMEMENTO_H

#include "Formula1Car.h"

class CarMemento{
private:
    Formula1Car* car;
public:
    Formula1Car* setState();
};

#endif //PROJECT_CARMEMENTO_H
