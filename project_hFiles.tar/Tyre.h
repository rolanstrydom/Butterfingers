//
// Created by Joanita on 2020/10/27.
//

#ifndef PROJECT_TYRE_H
#define PROJECT_TYRE_H

#include <iostream>
#include <string>

using namespace std;

class Tyre{
    string type;
    int thread;
};

#endif //PROJECT_TYRE_H
